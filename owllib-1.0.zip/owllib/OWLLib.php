<?php
/**
 *	Base class for accessing OWL ontology.
 *  @version	$Id: OWLLib.php,v 1.7 2004/04/28 11:43:38 klangner Exp $
 */

$OWLLIB_ROOT = dirname(__FILE__);

require_once "$OWLLIB_ROOT/OWLOntology.php";
require_once "$OWLLIB_ROOT/OWLClass.php";
require_once "$OWLLIB_ROOT/OWLInstance.php";
require_once "$OWLLIB_ROOT/OWLProperty.php";
 

?>
